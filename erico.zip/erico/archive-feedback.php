<?php get_header();
global $wp_post_types;
$post_type = 'feedback';
$description = $wp_post_types[$post_type]->description;
?>
<section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php  _e( 'Feedback','erico'); ?></h1>
        <h3><?php echo $description; ?></h3>
      </div>
    </div>
    <div class="breadcumb"> <a href="<?php echo home_url(); ?>"><?php  _e( 'HOME','erico'); ?></a>/<span><?php  _e( 'Feedback','erico'); ?></span> </div>
  </section>
  <section class="aboutus-details-section">
    <div class="container">
      <div class="row">
        <div class="aboutus-contents">
          <div class="row"> 
            <!--=======left section=====-->
            <div class="col-md-9">
              <div class="testimonial-carousal"> 
              
               <?php while ( have_posts() ) : the_post(); 
				global $post;
				  $feedback_author = get_field('client_name',$post->ID);
				?>
              
                <!-- SLIDES -->
                <div class="testimonial-slides">
                  <p><?php echo $post->post_content; ?></p>
                  <span class="client-name"><?php echo $feedback_author; ?></span> </div>
                <!-- SLIDES END -->
                <hr/>
                
                <!-- SLIDES -->
           
                <?php endwhile; ?>
                
                <!-- SLIDES END --> 
              </div>
            </div>
            
            <!--=======right section=====-->
            <?php echo get_sidebar(); ?>
            
            <!-- ABOUT TEXT --> 
            
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php
get_footer();?>