<?php get_header();
global $wp_post_types;
$post_type = 'news';
$description = $wp_post_types[$post_type]->description;
?>
<section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php  _e( 'News','erico'); ?></h1>
        <h3><?php echo $description; ?></h3>
      </div>
    </div>
    <div class="breadcumb"> <a href="<?php echo home_url(); ?>"><?php  _e( 'Home','erico'); ?></a>/<span><?php  _e( 'News','erico'); ?></span> </div>
  </section>
  
   <!--========Content Section=========-->
  
  <section class="aboutus-details-section">
    <div class="container">
      <div class="row">
        <div class="aboutus-contents">
          <div class="row"> 
            <!--=======left section=====-->
            <div class="col-md-9">
              <div class="news_box">
              
                <?php while ( have_posts() ) : the_post(); 
				global $post;?>
               	<h3><?php echo $post->post_title; ?> </h4>
                <h4><?php echo date('d-m-Y', strtotime($post->post_date));?> </h3>
               <?php echo $post->post_content; ?> </div>
              
            </div>
			
			<?php endwhile;?>
            
            <!--=======right section=====-->
            <?php get_sidebar(); ?>
            
            <!-- ABOUT TEXT --> 
            
          </div>
        </div>
      </div>
    </div>
  </section>
  
<?php 
get_footer();
?>