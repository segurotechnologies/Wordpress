<?php wp_footer(); ?>

<!--==========Footer Section=============-->

  <div class="footer_call_to_action">

    <div class="container-fluid">

      <div class="row">

        <div class="col-md-6 text-white">

          <?php echo get_theme_mod( 'footertxt_textbox' ); ?>

        </div>

        <div class="col-md-2 "> <a href="callto://<?php echo get_theme_mod( 'phone_textbox' ); ?>"><i class="icon-phone"></i>         <?php echo get_theme_mod( 'phone_textbox' ); ?></a>

        </div>

        <?php if(get_theme_mod('email_textbox')): ?>

        <div class="col-md-4 "> <a href="mailto:<?php echo get_theme_mod( 'email_textbox' ); ?>"><i class="icon-envelope"></i>        <?php echo get_theme_mod( 'email_textbox' ); ?></a></div>

        <?php endif; ?>

        </div>

       </div>

      </div>

  <footer class="footer">

    <div class="container-fluid">

      <div class="row">

        <div class="col-md-3">

              <h3 class="footer-widget-header"><?php  _e( 'Latest From Us','erico'); ?></h3>

              <strong><?php echo date('d.m.Y', strtotime($post->post_date));?></strong> <br>

                  <?php $the_query = new WP_Query( array( 'post_type' => 'news','posts_per_page' => 1,'order' => 'DESC','post_status'=>'publish' ));

                if ( $the_query->have_posts() ) : 

				 while ( $the_query->have_posts() ) : $the_query->the_post();

                global $post;

				?>

                <a href="<?php echo home_url(); ?>/news">

                <?php 

                $strl= strip_tags(strlen($post->post_content));

                if($strl>150)

                {

                    echo  strip_tags(substr($post->post_content,0,150))."...";

                }

                else

                {

                    echo  strip_tags($post->post_content);

                }?>

                </a>

                <?php 

                endwhile;

			 endif;?>

      </div>

        <div class="col-md-3">

          <h3 class="footer-widget-header"><?php  _e( 'Main Services','erico'); ?></h3>

          <div class="footer-category-widget">

            <ul>

            <?php $the_query = new WP_Query( array( 'post_type' => 'services','order' => 'ASC','post_status'=>'publish' ));

			if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();

            global $post;?>

			<li> <a href="<?php echo  get_permalink()?>"><?php echo $post->post_title; ?></a></li>

            <?php endwhile; endif; ?>

            </ul>

          </div>

        </div>

        <div class="col-md-3">

          <h3 class="footer-widget-header"><?php  _e( 'Contact US','erico'); ?></h3>

          <div class="footer-address">

            <ul>

              <li><i class="icon-map-pin"></i><?php echo get_theme_mod( 'address_textbox' ); ?></li>

              <li><i class="icon-phone"></i> <a href="callto://<?php echo get_theme_mod( 'phone_textbox' ); ?>"> <?php echo get_theme_mod( 'phone_textbox' ); ?></a> </li>

               <?php if(get_theme_mod('email_textbox')): ?>

              <li><i class="icon-envelope"></i> <a href="mailto:<?php echo get_theme_mod( 'email_textbox' ); ?>"> <?php echo get_theme_mod( 'email_textbox' ); ?></a> </li>

              <?php endif; ?>

            </ul>

          </div>

        </div>

        </div>

    </div>

  </footer>

  

  <!-- FOOTER END --> 

</div>



<!-- SOCIAL ICON -->

<div class="fixed-social-icon">

  <ul>

   <?php 

           $settings = get_option( 'sa_options', $sa_options );?>

           <li> <a href="<?php echo  $settings['facebook_link']; ?>"> <i class="fa fa-facebook"></i> </a> </li>

            <li> <a href="<?php echo  $settings['twitter_link']; ?>"> <i class="fa fa-twitter"></i> </a> </li>

            <li> <a href="<?php echo  $settings['instagram_link']; ?>"> <i class="fa fa-linkedin"></i> </a> </li>

            <li> <a href="<?php echo  $settings['googleplus_link']; ?>"> <i class="fa fa-google-plus"></i> </a> </li>

  </ul>

</div>

<!-- SOCIAL ICON END --> 



<!-- COPYRIGHT TEXT -->

<div class="copyright-text">

  <div class="row">

    <div class="col-md-5 text-center hidden-sm hidden-xs footer_no_wrap"> 

       <?php   

	     $settings = get_option( 'sa_options', $sa_options );

         $webtech_images= $settings['webtech_images'];	

		list( $array1, $array2 ) = array_chunk( $webtech_images, ceil(count($webtech_images) / 2) );

        foreach($array1 as $webimg) {

           ?>

        <img src="<?php echo $webimg; ?>"> <?php 

        } ?>  </div>

       <div class="col-md-2 footer_no_wrap">

       <p><?php echo get_theme_mod( 'copyright_textbox' ); ?></p>

       </div>

      <div class="col-md-5 text-center hidden-sm hidden-xs footer_no_wrap">  <?php  

	  foreach($array2 as $webimg1) {

       ?><img src="<?php echo $webimg1; ?>"> <?php } ?> </div>

      </div>

 </div>

<!-- COPYRIGHT TEXT END --> 

</body>

</html>