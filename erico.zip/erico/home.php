<?php

/* 

Template Name: Home

*/

?>

<?php 

get_header();

?>

<section class="hero-image">

    <div class="slider-pro hero-slider" id="hero-slider">

      <div class="sp-slides"> 
          <?php $headers = get_uploaded_header_images();
		 
		  if($headers !='')
		  {
			  foreach($headers as $key => $header) 
			  {
				  ?>
                     
        
        <!-- Slides -->
        <div class="sp-slide main-slides">
          <div class="dark-color-overlay"></div>
                  <?php 
              $header=$header['url'];?>
			  <img class="sp-image" src="<?php echo $header ?>" alt="<?php echo $header['alt_text'];?>"/>  
              <?php 
			  }
			  ?>
                </div>
        <!-- Slides End --> 
  <?php 
		  }
		  else
		  {?>
		 <img class="sp-image" src="<?php echo home_url(); ?>/wp-content/themes/erico/images/banner.jpg" alt="Slider 1"/>  
         <?php }?>
        </div>

  </div>
  </section>

   <!--========About Section=======-->

     <?php if ( have_posts() ) : ?>

        <?php while ( have_posts() ) : the_post();

		global $post;

		 ?>

  <section class="about-section section">

    <div class="container">

      <div class="row"> 

        <!-- SECTION HEADER -->

        <div class="section-headers">

          <h1><?php  _e( 'ABOUT US','erico'); ?></h1>

          <h3><?php  _e( 'WHO WE ARE','erico'); ?></h3>

        </div>

        <!-- SECTION HEADER END -->

        <div class="about-contents"> 

          <!-- ABOUT TEXT -->

          <div class="about-text">

            <p><?php echo the_field('main_text'); ?></p>

           </div>

          <!-- ABOUT TEXT END --> 

          

        </div>

      </div>

    </div>

  </section>

  <section class="split-section-wrapper">

    <div class="container-fluid">

      <div class="row">

        <div class="col-md-6">

        <?php  $image=get_field('image_hme'); ?>

       <img src="<?php echo $image['url']; ?>" width="615" height="257"> </div>

        <div class="col-md-6">

          <div class="custom-section-text">

          <?php echo the_field('subtext'); ?>

          </div>

        </div>

      </div>

    </div>

  </section>

  

  <!--============Services Section===========-->

  <section class="service-section-wrapper section">

    <div class="row">

      <div class="service-section"> 

        <!-- SECTION HEADER -->

        <div class="section-headers">

          <h1><?php  _e( 'SERVICES','erico'); ?></h1>

          <h3><?php  _e( 'WHAT WE OFFER','erico'); ?></h3>

        </div>

        <!-- SECTION HEADER END --> 

       <?php $the_query = new WP_Query( array( 'post_type' => 'services', 'posts_per_page' =>8,'order' => ASC,'post_status'=>'publish' ));

$i = 0;

if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();

global $post;

if($i % 4 == 0) {echo '</div><div class="service-row">';}

else if($i==0){echo  '</div><div class="service-row">';}

$service_icon_class =  get_field('service_icon_class',$post->ID);

?>



<div class="col-md-3 col-sm-3 col-xs-12 icontext-style-2">

            <div class="services_bg_box"> <a href="<?php the_permalink() ;?>"> <i class="<?php echo $service_icon_class; ?>"></i>

              <h3><?php echo $post->post_title; ?></h3>

              </a> </div>

          </div>

<?php $i++; endwhile; endif;?>



</div>

    </div>

  </section>

  

  <!--==== portfolio section========-->

  

  <section class="works-section-wrapper ">

    <div class="container">

      <div class="row"> 

        <!-- SECTION HEADER -->

        <div class="section-headers">

          <h1><?php  _e( 'Portfolio','erico'); ?></h1>

          <h3><?php  _e( 'What We Did','erico'); ?></h3>

        </div>

        <!-- SECTION HEADER END --> 

        

        <!-- WORKS -->

        <div class="works-wrapper"> 

          

          <!-- ALL WORK ITEMS -->

          <div class="works"> 

            <?php $loop = new WP_Query( array( 'post_type' => 'portfolio', 'posts_per_page' => 6 ,'order' => 'ASC','post_status'=>'publish') ); ?>

      <?php while ( $loop->have_posts() ) : $loop->the_post(); 

		 $custom = get_post_custom($post->ID); 

		  $portfolio_bigg_size = get_post_meta($post->ID, 'portfolio_bigg_size', true);

		  $img = get_the_post_thumbnail($post->ID);

		  $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') );

		  global $post;

		  ?>

            <!-- PORTFOLIO ITEM -->

            <div class="work-item <?php if($portfolio_bigg_size==1){  ?>height-dbl<?php } ?>">

              <div class="work-item-inner-wrap"> <?php echo $img; ?>

                <div class="work-item-hover"> <a href="<?php echo $url; ?>" class="lightbox"></a>

                  <h3> <a href="#"><?php echo $post->post_title; ?> </a> </h3>

                </div>

              </div>

            </div>

            <!-- PORTFOLIO ITEM END --> 

            <?php endwhile ?>

          </div>

          <!-- ALL WORK ITEMS END --> 

        </div>

        <!-- WORKS END --> 

      </div>

    </div>

  </section>

  

  <!--=========Testimonial Section==========-->

  <section class="testimonial-section-wrapper" data-stellar-background-ratio="0.5">

    <div class="container">

      <div class="row">

        <div id="testimonial-carousal" class="owl-carousel testimonial-carousal"> 

          <!-- SLIDES -->

          <?php $loop = new WP_Query( array( 'post_type' => 'feedback', 'posts_per_page' => 10 ,'order' => 'DESC','post_status'=>'publish') ); ?>

      <?php while ( $loop->have_posts() ) : $loop->the_post(); 

	  	global $post;

			$feedback_author = get_field('client_name',$post->ID);?>

         <!-- SLIDES -->

          <div class="testimonial-slides">

           <a href="<?php echo home_url(); ?>/feedback"> <p><?php  $strl= strip_tags(strlen($post->post_content));

					if($strl>250)

					{

					echo  strip_tags(substr($post->post_content,0,250))."...";

					}

					else

					{

					echo  strip_tags($post->post_content);

					}

					?></p></a>

            <span class="client-name"><?php echo $feedback_author; ?></span> </div>

            <?php endwhile;?>

          <!-- SLIDES END --> 

          

        </div>

      </div>

    </div>

  </section>

  

  <!--===========Blog Section===========-->

  

  

  <?php endwhile;

  endif;

  ?>

 <?php 

get_footer();

?>