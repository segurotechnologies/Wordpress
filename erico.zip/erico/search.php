<?php get_header(); ?>
  <section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php printf( __( 'Search Results for: %s', 'erico' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
      </div>
    </div>
  </section>
  
 <!--========Content Section=========-->
  
  <section class="aboutus-details-section">
    <div class="container">
      <div class="row">
        <div class="aboutus-contents">
          <div class="row"> 
            <!--=======left section=====-->
            <div class="col-md-9">
            	<?php if(have_posts()): ?>
				<?php while ( have_posts() ) : the_post(); ?>
                
                <?php
                /**
                * Run the loop for the search to output the results.
                * If you want to overload this in a child theme then include a file
                * called content-search.php and that will be used instead.
                */
                get_template_part( 'content', 'search' );
                ?>                
                <?php endwhile; ?>
                <?php else: ?>
					<div class="alert alert-warning" role="alert"><?php  _e( 'Sorry No Result.','erico'); ?></div>
                <?php endif; ?>
            </div>
            <?php echo get_sidebar('page') ?>            
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!--=====Testimonail=========-->
  <section class="testimonial-section-inner" data-stellar-background-ratio="0.5"> 
    <div class="container">
      <div class="row">
        <div id="testimonial-carousal" class="owl-carousel testimonial-carousal"> 
            <?php 
			$loop = new WP_Query( array( 'post_type' => 'feedback','order' => 'DESC','post_status'=>'publish') ); ?>
           <?php 
		   while ( $loop->have_posts() ) : $loop->the_post(); 
	  	   $feedback_author = get_field('client_name',$post->ID);
		  global $post;?>
          <!-- SLIDES -->
          <div class="testimonial-slides">
          <a href="<?php echo home_url(); ?>/feedback"> <p><?php  $strl= strip_tags(strlen($post->post_content));
					if($strl>250)
					{
						echo  strip_tags(substr($post->post_content,0,250))."...";
					}
					else
					{
						echo  strip_tags($post->post_content);
					}
					?></p></a>
            <span class="client-name"><?php echo $feedback_author; ?></span> </div>
          <!-- SLIDES END --> 
          <?php endwhile;?>
        </div>
      </div>
    </div>
  </section>
<!--==== Section End ====--> 
<?php get_footer(); ?>