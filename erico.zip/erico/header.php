<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width">
<!-- GOOGLE FONT -->
<link href='http://fonts.googleapis.com/css?family=Fjalla+One' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:700,600,400' rel='stylesheet' type='text/css'>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<?php wp_head(); ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-76076203-1', 'auto');
  ga('send', 'pageview');
</script>
</head>
<body <?php body_class('homepage-one' ); ?>>
<!-- PRELOADER -->
<div class="loader-overlay"></div>
<div id="loader-wrapper">
  <div id="loader"> <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/themes/Erico/images/logo-loader.png" alt="ERICO" class="animated fadeIn"> <span>Loading</span> </div>
  <div class="loader-section section-left"></div>
  <div class="loader-section section-right"></div>
</div>
<!-- PRELOADER END --> 
<!-- BORDERS -->
<div class="mainborder-top"></div>
<div class="mainborder-left"></div>
<div class="mainborder-right"></div>
<div class="mainborder-bottom"></div>
<!-- BORDERS END --> 

<!--SIDE MENU--> 
<!-- PAGE OVERLAY WHEN MENU ACTIVE -->
<div class="side-menu-overlay"></div>
<!-- PAGE OVERLAY WHEN MENU ACTIVE END -->

<div class="side-menu-wrap"> 
  <!-- OVERLAY -->
  <div class="dark-overlay"></div>
  <!-- OVERLAY END -->
  <nav class="side-menu">
    <div class="side-menu-widget-wrap"> 
      <!-- LOGO -->
      <div class="side-menu-logo-wrap">
        <h3><?php  _e( 'Quick Contact','erico'); ?> </h3>
      </div>
      <!-- LOGO --> 
      
      <!-- WIDGETS -->
      <div class="side-menu-menu-wrap">
        <div class="side-menu-menu-widget">
        
         <?php echo do_shortcode('[contact-form-7 id="86" title="Contact form 1"]'); ?>
        <h3> <a href="callto://<?php echo get_theme_mod( 'phone_textbox' ); ?>"><i class="fa fa-phone"> </i> <?php echo get_theme_mod( 'phone_textbox' ); ?> </a></h3>
          <?php if(get_theme_mod( 'email_textbox' )): ?>	
          <h3><a href="mailto:<?php echo get_theme_mod( 'email_textbox' ); ?>"><i class="fa fa-envelope"></i> &nbsp; <?php echo get_theme_mod( 'email_textbox' ); ?></a></h3>
          <?php endif; ?>
        </div>
        <div class="side-menu-social-icon">
          <ul>
          <?php 
           $settings = get_option( 'sa_options', $sa_options );?>
            <li> <a href="<?php echo  $settings['facebook_link']; ?>"> <i class="fa fa-facebook"></i> </a> </li>
            <li> <a href="<?php echo  $settings['twitter_link']; ?>"> <i class="fa fa-twitter"></i> </a> </li>
            <li> <a href="<?php echo  $settings['instagram_link']; ?>"> <i class="fa fa-linkedin"></i> </a> </li>
            <li> <a href="<?php echo  $settings['googleplus_link']; ?>"> <i class="fa fa-google-plus"></i> </a> </li>
          </ul>
        </div>
      </div>
      <!-- WIDGETS END --> 
    </div>
  </nav>
  <button class="side-menu-close-button" id="side-menu-close-button"><?php  _e( 'Close Menu','erico'); ?> </button>
</div>
<!-- SIDE MENU END -->
<div class="main-page-contents">
  <!-- HEADER -->
  <header class="fixed-header">
    <div class="container-fluid">
      <div class="row"> 
        <!-- Navigation Menu start-->
        <nav class="navbar main-menu" role="navigation"> 
          <!-- Navbar Toggle -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <!-- Logo --> 
           <a class="navbar-brand" href="<?php echo home_url(); ?>"><img class="logo" id="logo" src="<?php echo get_theme_mod( 'erico_logo' ); ?>" alt=""></a> </div>
          <!-- Navbar Toggle End --> 
          <!-- navbar-collapse start-->
          <div id="nav-menu" class="navbar-collapse collapse" role="navigation">
          <?php
       $defaults = array(
	'menu'            => 'Mainmenu',
    'menu_class'      => 'nav navbar-nav menu-wrapper',
    'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	'depth'           => 0,
	'walker'          => '',
    'container'       => '',
      );
	  wp_nav_menu( $defaults );

     ?>
        </div>
          <!-- navbar-collapse end--> 
          
          <!-- SIDE MENU BTN -->
          <div class="side-menu-contact"> <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/themes/Erico/images/quick-contact-icon.png" style="position:absolute;"></div>
          <div class="side-menu-opener">
            <button class="side-menu-button" id="side-menu-open-button"> <i class="fa fa-archive"> </i></button>
          </div>
          <!-- SIDE MENU BTN END --> 
        </nav>
        <!-- Navigation Menu end--> 
      </div>
    </div>
  </header>
  <!-- HEADER END -->
    <section>
    <div class="main_banner_top_band">
      <div class="nav-pad"><?php $the_query = new WP_Query( array( 'post_type' => 'services','order' => 'ASC','post_status'=>'publish','posts_per_page' => 9 ));

//custom post services

if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
global $post;
?>
<a href="<?php echo  get_permalink()?>"><?php echo $post->post_title; ?></a>
<?php endwhile;endif;
 ?>
</div>
</div>
</section>