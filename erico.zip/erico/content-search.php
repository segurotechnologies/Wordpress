<div class="panel panel-default">
<div class="panel-heading"><h3 class="panel-title"><?php the_title(); ?></h3></div>
<div class="panel-body">
<?php the_excerpt(); ?>
</div>
</div>
