<?php
// Default options values

$sa_options = array(

	'footer_copyright' => '&copy; ' . date('Y') . ' ' . get_bloginfo('name'),
);


add_action('admin_menu', 'sa_theme_options');

function sa_theme_options() {

	// Add theme options page to the admin menu
add_theme_page('Theme Options', 'Theme options', 'edit_theme_options', 'erico_themeoptions', 'theme_options');

}
function sa_register_settings() {

	// Register settings and call sanitation functions

	wp_enqueue_style( 'theme-option-css', get_template_directory_uri() . '/css/admincustom_css.css');

	wp_enqueue_style( 'theme-option-tabmodule', get_template_directory_uri() . '/css/tabModule.css');

	wp_enqueue_script( 'theme-option-js', get_template_directory_uri() . '/js/admin_customjs.js', array(), '1.0.0', true );

	register_setting( 'sa_theme_options', 'sa_options', 'sa_validate_options' );

}



add_action( 'admin_init', 'sa_register_settings' );

// Function to generate options page
function theme_options() {
global $sa_options, $sa_categories, $sa_layouts;

	if ( ! isset( $_REQUEST['updated'] ) )

		$_REQUEST['updated'] = false; // This checks whether the form has just been submitted. ?>
    <div class="wrap">
    <?php echo "<h2>Theme Options</h2>";

	// This shows the page's name and an icon if one has been provided ?>
<?php if ( false !== $_REQUEST['updated'] ) : ?>

	<div class="updated fade"><p><strong><?php  _e( 'Options saved','erico'); ?></strong></p></div>

	<?php endif; // If the form has just been submitted, this shows the notification ?>

   <form method="post" action="options.php" enctype="multipart/form-data">

         	<?php $settings = get_option( 'sa_options', $sa_options ); ?>

           <?php
       settings_fields( 'sa_theme_options' );

	/* This function outputs some hidden fields required by the form,

	including a nonce, a unique number used to ensure the form has been submitted from the admin page */ ?>

            

            <div class="demo">

		   <div class="tab tab-horiz">

			<ul class="tab-legend">

            <li><?php  _e( 'Tags','erico'); ?></li>

            <li><?php  _e( 'Social Links','erico'); ?></li>

			</ul>

			<ul class="tab-content erico_theme_panel">

			

           <li> 

               <table>

               <tr><td colspan="3"> <h4 class="hndle"><span><?php  _e( 'Tags','erico'); ?></span></h4></td></tr>             

				</table>

              <table class="addedRows"> <tbody> <?php   $webimg= $settings['webtech_images'];			

			

		if($webimg=='')
         {

			?>
             <tr id="rowCount1">

              <td>

              <input  type="text" size="36" name="sa_options[webtech_images][]" class="webupload_image" value=""  />

              <input  type="button" value="Upload Image" class="webupload_image_button" /></td>

             <td>  <div class="imgclass"></div></td>

              <td> <a href="javascript:void(0);" class="delete_row" onclick="removeRow(1);"><?php  _e( 'Delete','erico'); ?></a></td>

              </tr>

              <?php }

			    else

              {
				  $i=1;

				 foreach($webimg as $item) {

				?>

                  <tr id="rowCount<?php echo $i; ?>">

              <td><input  type="button" value="Upload Image" class="webupload_image_button" /> <input type="text" size="36"  name="sa_options[webtech_images][]" class="webupload_image" value="<?php echo $item; ?>" /><td>

                <div class="imgclass"><img src="<?php echo $item; ?>"  /></div></td>

         </td><td> <a href="javascript:void(0);" class="delete_row" onclick="removeRow(<?php echo $i;?>);"><?php  _e( 'Delete','erico'); ?></a></td>

              </tr>

                  <?php

				  $i++;

				  }

              } ?>

 <tr>

              <td><span class="add_row" style="font:normal 12px agency, arial; color:#FFF; text-decoration:underline; cursor:pointer;" onclick="addMoreRows(this.form);"><?php  _e( 'Add More','erico'); ?> 

             </span>

             </td>

             </tr>

            </table>

           <p class="submit"><input type="submit" class="button-primary" value="Save Options" /></p>

         </li>

         

		<li>

			   <table>

               <tbody>   

               <tr>

               <td colspan="3"> <h4 class="hndle" ><span><?php  _e( 'Social Links','erico'); ?></span></h4></td>

               </tr>

               

               <tr><td><div class="themeopt_title"><?php  _e( 'Facebook','erico'); ?> </div></td>

               <td><input type="text"  name="sa_options[facebook_link]" id="facebook_link" value="<?php echo  $settings['facebook_link']; ?>"/></td>

               </tr>

               <tr><td><div class="themeopt_title"><?php  _e( 'Twitter','erico'); ?></div></td>

               <td><input type="text"  name="sa_options[twitter_link]" id="twitter_link" value="<?php echo $settings['twitter_link']; ?>"/></td>

               </tr>

               <tr><td><div class="themeopt_title"><?php  _e( 'Linkedin','erico'); ?></div></td>

               <td><input type="text"  name="sa_options[instagram_link]" id="instagram_link" value="<?php echo $settings['instagram_link']; ?>"/></td>

               </tr>

                  <tr><td><div class="themeopt_title"><?php  _e( 'Google+','erico'); ?></div></td>

               <td><input type="text"  name="sa_options[googleplus_link]" id="googleplus_link" value="<?php echo  $settings['googleplus_link']; ?>"/></td>

               </tr>

               	</tbody>

                </table>

              <p class="submit"><input type="submit" class="button-primary" value="Save Options" /></p>

          </li>

		</ul>

		</div>

	</div>

    </form>

            </div>
<?php

}



function sa_validate_options( $input ) {

	global $sa_options, $sa_categories, $sa_layouts;

$settings = get_option( 'sa_options', $sa_options );

	// We strip all tags from the text field, to avoid vulnerablilties like XSS

	$input['footer_copyright'] = wp_filter_nohtml_kses( $input['footer_copyright'] );

	// We strip all tags from the text field, to avoid vulnerablilties like XSS

return $input;

}



function my_admin_scripts() {

wp_enqueue_script('media-upload');

wp_enqueue_script('thickbox');



wp_enqueue_script('my-upload');

}

 

function my_admin_styles() {

wp_enqueue_style('thickbox');

}

 



add_action('admin_print_scripts', 'my_admin_scripts');

add_action('admin_print_styles', 'my_admin_styles');