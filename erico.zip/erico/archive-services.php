<?php 
echo get_header();
global $wp_post_types;
$post_type = 'services';
$description = $wp_post_types[$post_type]->description;
?>
<section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php  _e( 'Services','erico'); ?></h1>
        <h3><?php echo $description; ?></h3>
      </div>
    </div>
    <div class="breadcumb"> 
          <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>  
    </div>
  </section>

<!--========Content Section=========-->  
  <section class="aboutus-details-section">
    <div class="container">
      <div class="row">
        <div class="aboutus-contents">
          <div class="row"> 
            <!--=======left section=====-->
            <div class="col-md-9">
              <div class="service-section"> 
                <!-- ROW 1 -->
                <div class="service-row">
                  <div class="row">
                  <?php 
                    while ( have_posts() ) : the_post();
	          global $post;
			    $service_icon_class = get_field('service_icon_class__in_service',$post->ID);?>
                    <div class="col-md-4 col-sm-4 col-xs-12 icontext-style-2">
                      <div class="icontext-icon-wrapper"> <i class="<?php echo $service_icon_class; ?> animated"></i> </div>
                      <div class="icontext-text"> <a href="<?php the_permalink() ;?>">
                        <h3><?php echo $post->post_title; ?></h3>
                        </a>
                     <a href="<?php the_permalink() ;?>" ><p><?php  $strl= strip_tags(strlen($post->post_content));
					if($strl>150)
					{
					echo  strip_tags(substr($post->post_content,0,150))."...";
					}
					else
					{
					echo  strip_tags($post->post_content);
					}
					?></p></a>
                      </div>
                    </div>
                   <?php     	endwhile; ?>
                    
                    <!--end row--> 
                  </div>
                  <!-- ROW 2 END--> 
                </div>
              </div>
            </div>
            
          <?php echo get_sidebar(); ?>
            
            <!-- ABOUT TEXT --> 
            
          </div>
        </div>
      </div>
    </div>
  </section>
   <!--=====Testimonail=========-->
  <section class="testimonial-section-inner" data-stellar-background-ratio="0.5"> 
    <div class="container">
      <div class="row">
        <div id="testimonial-carousal" class="owl-carousel testimonial-carousal"> 
            <?php $loop = new WP_Query( array( 'post_type' => 'feedback','order' => 'DESC','post_status'=>'publish') ); ?>
      <?php while ( $loop->have_posts() ) : $loop->the_post(); 
	  		  $feedback_author = get_field('client_name',$post->ID);
		  global $post;
		  ?>
          <!-- SLIDES -->
          <div class="testimonial-slides">
       <a href="<?php echo home_url(); ?>/feedback"> <p><?php  $strl= strip_tags(strlen($post->post_content));
					if($strl>250)
					{
						echo  strip_tags(substr($post->post_content,0,250))."...";
					}
					else
					{
						echo  strip_tags($post->post_content);
					}
					?></p></a>
            <span class="client-name"><?php echo $feedback_author; ?></span> </div>
          <!-- SLIDES END --> 
          <?php endwhile;?>
        </div>
      </div>
    </div>
  </section>
  <?php 
echo get_footer();
?>