<?php get_header(); ?>

  <section class="page-title-section">

    <div class="container">

      <div class="row">

        <h1><?php _e( 'Page Not Found', 'erico' ); ?></h1>

        <h3><?php _e( 'Well this does not look good.<br />It appears this page is missing or was removed.', 'erico' ); ?></h3>

      </div>

    </div>

  </section>

  

 <!--========Content Section=========-->

  

  <section class="aboutus-details-section">

    <div class="container">

      <div class="row">

        <div class="aboutus-contents">

          <div class="row"> 

            <!--=======left section=====-->

            <div class="col-md-9">

            	<h4 style="color:#C90000; margin-bottom:0px;"><?php _e( 'If what you were looking for is not found, you may want to try searching with keywords relevant to what you were looking for.', 'erico' ); ?></h4><br/>

                <div class="text-center">

                <img style="margin:10px 0;" alt="" src="<?php echo get_template_directory_uri(); ?>/images/404-image.png" />

                </div>

                <div class="input-group-box">

                    <div id="custom-search-input" style="margin-bottom:15px;">

                        <div class="input-group col-md-12">

                        	<form role="search" method="get" id="searchform row" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">

                            

                            <div class="col-md-11" style="padding:0px;">

                            	<input type="text" class="form-control" placeholder="Search" value="<?php echo get_search_query(); ?>" name="s" id="s" />

                            </div>				

                            <div class="col-md-1" style="padding-left:0px;">

                                <span class="input-group-btn">

                                <button type="submit" style="background-color:#FFCC33; width:100%; border:1px solid #000000" class="btn btn-danger">

                                <span style="color:#1B1B1B;" class="fa fa-search"></span>

                                </button>

                                </span>

                            </div>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

            <?php echo get_sidebar('page') ?>

            

          </div>

        </div>

      </div>

    </div>

  </section>

  

  <!--=====Testimonail=========-->

  <section class="testimonial-section-inner" data-stellar-background-ratio="0.5"> 

    <div class="container">

      <div class="row">

        <div id="testimonial-carousal" class="owl-carousel testimonial-carousal"> 

            <?php 

			$loop = new WP_Query( array( 'post_type' => 'feedback','order' => 'DESC','post_status'=>'publish') ); ?>

           <?php 

		   while ( $loop->have_posts() ) : $loop->the_post(); 

	  	   $feedback_author = get_field('client_name',$post->ID);

		  global $post;?>

          <!-- SLIDES -->

          <div class="testimonial-slides">

          <a href="<?php echo home_url(); ?>/feedback"> <p><?php  $strl= strip_tags(strlen($post->post_content));

					if($strl>250)

					{

						echo  strip_tags(substr($post->post_content,0,250))."...";

					}

					else

					{

						echo  strip_tags($post->post_content);

					}

					?></p></a>

            <span class="client-name"><?php echo $feedback_author; ?></span> </div>

          <!-- SLIDES END --> 

          <?php endwhile;?>

        </div>

      </div>

    </div>

  </section>

<!--==== Section End ====--> 

<?php get_footer(); ?>