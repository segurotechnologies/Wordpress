<?php

/**

 * sidebar group. 

 * @package erico

 * @since 1.0.0

 */



?>



  <!--=======right section=====-->

            <div class="col-md-3 side_bar_blog">

              <div class="widget_blog">

                <h3> <?php  _e( 'Portfolio','erico'); </h3>

                <div id="carousel-example-generic" class="carousel slide portfoilio_side_section"> 

                  <!-- Indicators -->

                  <ol class="carousel-indicators">

                   <?php $loop = new WP_Query( array( 'post_type' => 'portfolio', 'posts_per_page' => 10 ,'order' => 'ASC', 'post_status'=>'publish') );

				   $query_cnt=$loop->found_posts;

				   for($i=0;$i<10;$i++)

				   {

					   if($i==0)

					    { ?>

                        <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i; ?>" class="active"></li>

				   <?php } 

						else

						   { ?>

						<li data-target="#carousel-example-generic" data-slide-to="<?php echo $i; ?>"></li>

				   <?php }

				   }?>

			      </ol>

                  <!-- Wrapper for slides -->

                 <div class="carousel-inner" role="listbox">

                  <?php 

					$k=0;

					while ( $loop->have_posts() ) : $loop->the_post(); 

					$custom = get_post_custom($post->ID); 

					$portfolio_bigg_size = get_post_meta($post->ID, 'portfolio_bigg_size', true);

					$url = get_the_post_thumbnail($post->ID);

					

					global $post;

					if($k==0)

					{

					?> <div class="item active portolio_side"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>/portfolio"><?php echo $url; ?> </a> </div>

					<?php } else {

					?>

					<div class="item portolio_side"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>/portfolio"> <?php echo $url; ?></a> </div>

					<?php } $k++; ?>

                    <?php  endwhile; ?>

                 </div>

                </div>

              </div>

              <!--next-->

              <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>

              <div class="widget_blog">

                <h3><?php _e( 'Require a free consultation?','erico'); ?> </h3>

              <?php  dynamic_sidebar('sidebar-1'); ?>

              </div>

              <?php endif; ?>

              <!--end--> 

              </div>