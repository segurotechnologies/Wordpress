<?php 

get_header();

global $wp_post_types;

$post_type = 'blog';

$description = $wp_post_types[$post_type]->description;



?>

<?php 

      while ( have_posts() ) : the_post();

	  global $post;

	  	 $custom = get_post_custom($post->ID); 

		  $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') );

		?>

 <section class="page-title-section">

    <div class="container">

      <div class="row">

        <h1>Blog</h1>

        <h3><?php echo $description; ?></h3>

      </div>

    </div>

    <div class="breadcumb"> <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>   </div>

  </section>

  

  <!--========Content Section=========-->

  <section class="aboutus-details-section">

    <div class="container">

      <div class="row">

        <div class="aboutus-contents">

          <div class="row"> 

            <!--=======left section=====-->

            <div class="col-md-9 blog-single-section">

              <div class="blog-single-content"> 

                <!-- POST TITLE -->

                <div class="blog-page-title-meta">

                  <h1><?php the_title(); ?></h1>

                  <span class="post-date"><?php echo get_the_date( 'F d,Y' ); ?></span>

                  <p class="post-meta">By <?php echo get_field('author',$post->ID); ?> </p>

                </div>

                <!-- POST TITLE END -->

                

                <div class="blog-single-details"> 

                  <!-- POST IMAGE -->

                  <div class="blog-page-feat-img"> <img src="<?php echo $url; ?>" alt="Blog Single Image"> </div>

                  <!-- POST IMAGE END --> 

                  

                  <!-- POST TEXT -->

                  <div class="blog-page-details-text">

                 <?php the_content(); ?>

                    <div class="blog_share"> <a href="#" class="btn btn-default">SHARE <i class="fa fa-share-alt"></i> </a> <a href="#" class="btn btn-primary"> <i class="fa fa-facebook"></i> </a> <a href="#" class="btn btn-info"> <i class="fa fa-twitter"></i> </a> <a href="#" class="btn btn-danger"> <i class="fa fa-google-plus"></i> </a> <a href="#" class="btn btn-info"> <i class="fa fa-linkedin"></i> </a> </div>

                  </div>

                </div>

              </div>

            </div>

            <?php endwhile; ?>

            

            <!--=======right section=====-->

            <div class="col-md-3 side_bar_blog side_bar_blog_pic"> 

              <!--===widget 1=========-->

              <div class="widget_blog">

                <h3>Recent Posts</h3>

                <ul class="recent_post">

                             <?php

        $new_loop = new WP_Query( array(

    'post_type' => 'blog',

        'posts_per_page' => 6,

		'order'=>'ASC',

	    'post_status'=>'publish'

		 // put number of posts that you'd like to display

    ) );

?>



<?php if ( $new_loop->have_posts() ) : ?>

    <?php while ( $new_loop->have_posts() ) : $new_loop->the_post();

	  global $post; ?>

                  <li><a href="<?php echo  get_permalink()?>"><?php echo $post->post_title;  ?></a></li>

          <?php endwhile;

				  endif;

				   ?>

                </ul>

              </div>

              <!--===widget 2======-->

              <div class="widget_blog">

                <h3><?php  _e( 'Archives','erico'); ?></h3>

                <ul class="list_arrow">

                     <?php echo cpt_wp_get_archives('blog'); ?>

                </ul>

              </div>

              <!--======widget 3 ========-->

              <div class="widget_blog">

                <h3><?php  _e( 'Categories','erico'); ?></h3>

                <ul class="list_arrow">

                            <?php   

              	   $taxonomy = 'blog_taxonomy';

                   $tax_terms = get_terms($taxonomy);?>

                

                  <?php

                   foreach ($tax_terms as $tax_term) 

				   {

                   echo '<li><a href="'.get_permalink().'" title="' . $tax_term->name. '>' . $tax_term->name.'</a></li>';

				   }?>

                </ul>

              </div>

              

              <!--======widget 4 ========-->

              <div class="widget_blog">

                <h3><?php  _e( 'Tags','erico'); ?></h3>

                <?php  $terms = get_terms('post_tag'); ?>

                <ul class="list_arrow">

                <?php 

				foreach ($terms as $term) {

                	    $url = esc_attr(get_term_link($term,'tag') );

echo '<li><a href="'.$url.'" title="'.$term->name. '" ' . '>' . $term->name.'</a></li>';

				}

?>

                </ul>

              </div>

              <!--==========End Section=========--> 

            </div>

            

            <!-- ABOUT TEXT --> 

            

          </div>

        </div>

      </div>

    </div>

  </section>

<?php 

get_footer();

?>