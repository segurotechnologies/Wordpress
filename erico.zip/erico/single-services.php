<?php 
get_header();

while ( have_posts() ) : the_post();
	  global $post;
	   $post_title=$post->post_title;
	  	 $custom = get_post_custom($post->ID); 
		  $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') );
		?>
 <section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php the_title(); ?></h1>
        <h3><?php echo get_field('title',$post->ID); ?></h3>
      </div>
    </div>
    <div class="breadcumb">  <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>  </span></div>
  </section>
  
 
  <!--========Content Section=========-->
  
  <section class="aboutus-details-section">
    <div class="container">
      <div class="row">
        <div class="aboutus-contents">
          <div class="row"> 
            <!--=======left section=====-->
            <div class="col-md-9">
              <div class="service-section"> 
                <!-- ROW 1 -->
                <div class="service-row">
              <?php the_content(); ?>
                </div>
              </div>
            </div>
            
            <!--=======right section=====-->
            
            <?php echo get_sidebar(); ?>
            
             <!--=======right section=====-->
            
           </div>
        </div>
      </div>
    </div>
  </section>
  <?php endwhile; ?>
  
<?php 
get_footer();
?>