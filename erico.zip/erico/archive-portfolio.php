<?php 
echo get_header();

global $wp_post_types;
$post_type = 'portfolio';
$description = $wp_post_types[$post_type]->description;
$taxonomy = 'portfolio_taxonomy';
$tax_terms = get_terms($taxonomy);
?>
<section class="page-title-section">
    <div class="container">
      <div class="row">
        <h1><?php  _e( 'Portfolio','erico'); ?></h1>
        <h3><?php echo $description; ?></h3>
      </div>
    </div>
    <div class="breadcumb"><a href="<?php echo home_url(); ?>"><?php  _e( 'HOME','erico'); ?></a> /<span><?php  _e( 'Portfolio','erico'); ?></span>   </div>
  </section>

  <!--========Content Section=========-->
  
 <section class="aboutus-details-section portfolio-masonry-section">
  <div class="container">
    <div class="row"> 
      <!-- WORKS -->
      <div class="works-wrapper"> 
        <!-- FILTER -->
        <div class="filter-link-wrapper"> 
          <!-- Filter Button Start -->
          <div id="portfolio-filter" class="portfolio-filter-btn-group-wrapper">
            <div class="portfolio-filter-btn-group"> <a href="#" class="selected" data-filter="*"><?php  _e( 'ALL','erico'); ?></a>
              <?php  foreach ($tax_terms as $tax_term) {?>
                                  <a href="#" data-filter=".<?php echo $tax_term->slug; ?>"><?php echo $tax_term->name; ?></a>
                                         <?php }?>
                                         
                                         </div>
          </div>
          <!-- Filter Button End --> 
        </div>
        <!-- FILTER END --> 
        
        <!-- ALL WORK ITEMS -->
        <div class="works"> 
          <?php 
       $post_type = 'portfolio'; ?>
   <?php
         $args = array(

                'post_type' => $post_type,

                'posts_per_page' => -1,  

 );
 $taxargs = array('orderby' => 'name', 'order' => 'ASC', 'fields' => 'all');



        $loop = new WP_Query($args);
		 while ( $loop->have_posts() ) : $loop->the_post();
		 global $post;
		  $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') );
		  $terms = wp_get_post_terms($post->ID,'portfolio_taxonomy', $taxargs );
		  $termTax = '';
		  foreach($terms as $term){
			$termTax .= $term->slug.' ';  
		  }
		  ?>
          
          
          <div class="work-item <?php echo $termTax; //echo $term->slug; ?>" id="<?php echo the_title(); ?>">
            <div class="work-item-inner-wrap portfolio_img"> <img src="<?php echo $url; ?>" alt="Portfolio Item" />
              <div class="work-item-hover"> <a href="<?php echo $url; ?>" class="lightbox"></a>
                <h3> <a href="#">
                
                <?php $tags= get_field('tags',$post->ID);
		
			   $cnt=count($tags);
				
				for($i=0;$i<$cnt;$i++)
				{
					if($i==($cnt-1))
					{
						echo $tags[$i]['tags'];
					}
					else
					{
						echo $tags[$i]['tags'].",";
					}
				}
				 ?>
               </a> </h3>  </div>
            </div>
          </div>
          <!-- PORTFOLIO ITEM END --> 
         <?php
 endwhile;
 //endforeach; 
 //endforeach; 
?>
    
 
          
        </div>
      
       
      </div>
      <!-- WORKS END --> 
    </div>
  </div>
</section>
<?php 
echo get_footer();