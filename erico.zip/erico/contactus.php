<?php

/* 

Template Name: Contact Us

*/

?>

<?php 

get_header();

while ( have_posts() ) : the_post();?>

<section class="page-title-section">

    <div class="container">

      <div class="row">

        <h1>Contact US</h1>

        <h3><?php echo get_field('title'); ?></h3>

      </div>

    </div>

    <div class="breadcumb"><?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?> </div>

  </section>

  

  <!--========Content Section=========-->

  

  <section class="contact-us-section">

    <div class="container">

      <div class="row">

        <div class="contact-address-div"> 

          

          <!-- CONTACT DETAILS -->

          <div class="contact-details">

            <div class="contact-form-wrapper col-md-8 col-sm-7 col-xs-12">

              <p><?php  _e( 'Please fill in the requested details. We will get back to you soon...','erico'); ?></p>

              <div class="contact-form">

              

                  <?php echo do_shortcode('[contact-form-7 id="88" title="Untitled"]'); ?>

            

              </div>

            </div>

            

            <!-- CONTACT ADDRESS -->

            <div class="contact-address-wrapper col-md-4 col-sm-4 col-xs-12 contact_us_pic"> 

              

              <!-- ADDRESS 1 -->

              <div class="contact-address">

                <h4><?php  _e( 'Address','erico'); ?></h4>

                <ul>

                  <li> <i class="fa fa-home"></i><?php echo get_theme_mod( 'address_textbox' ); ?> </li>

                  <li> <i class="fa fa-phone"></i><?php echo get_theme_mod( 'phone_textbox' ); ?></li>

                  <li><i class="fa fa-envelope"></i> <a href="mailto:<?php echo get_theme_mod( 'email_textbox' ); ?>"><?php echo get_theme_mod( 'email_textbox' ); ?></a></li>

                </ul>

              </div>

            </div>

            <!-- CONTACT ADDRESS END --> 

          </div>

          <!-- CONTACT DETAILS END --> 

        </div>

      </div>

    </div>

  </section>

<?php 

endwhile;

get_footer();

?>