/* ==================================================================
                		PRELOADER
================================================================== */
$(window).load(function(){
	jQuery("#loader").fadeOut(200);
 	jQuery('body').addClass('loaded');
	jQuery('div.loader-overlay').fadeOut('slow');
	
	
});

$(document).ready(function(){
	"use strict";
	
	var html_margin = $('html').css('margin-top');
	var headerHeight = $('.fixed-header').height();
	var heighDec = html_margin.split('px')[0];
	var fulltroat = parseInt(heighDec)+parseInt(headerHeight);
	if(html_margin != '0px'){
		$('.fixed-header').css({'top':html_margin});
		$('.side-menu-overlay').css({'top':(fulltroat)+'px'});
		$('.side-menu-wrap').css({'top':(parseInt(heighDec))+'px'});
	}
	
	$('div.upload-section input.upload_css').change(function(event){
		var thisval = $(this).val();
		$('#upload_text').val(thisval);
	});

/* ==================================================================
                FOR SCROLL UP BUTTON
================================================================== */
	$.scrollUp({
		scrollName: 'scrollUp', // Element ID
		scrollDistance: 0, // Distance from top/bottom before showing element (px)
		scrollFrom: 'top', // 'top' or 'bottom'
		scrollSpeed: 300, // Speed back to top (ms)
		easingType: 'linear', // Scroll to top easing (see http://easings.net/)
		animation: 'fade', // Fade, slide, none
		animationInSpeed: 200, // Animation in speed (ms)
		animationOutSpeed: 200, // Animation out speed (ms)
		scrollText: '<i class="pe-7s-angle-up"></i> Go Top', // Text for element, can contain HTML
		scrollTitle: true, // Set a custom <a> title if required. Defaults to scrollText
		scrollImg: false, // Set true to use image
		activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
		zIndex: 10001 // Z-Index for the overlay
	});
	
	jQuery('#carousel-example-generic').carousel({
  interval: 5000
})


/* ==================================================================
                USED FOR CLICK TO HIDE MENU
================================================================== */
jQuery(".nav a").on("click", function () {
    jQuery("#nav-menu").removeClass("in").addClass("collapse")
});




/* ==================================================================
                		Homepage Slider
================================================================== */
	$( '#hero-slider' ).sliderPro({
		width: '100%',
		// height: '100%',
	    fade: true,
	    forceSize: 'fullWindow',
	    arrows: true,
	    waitForLayers: true,
	    buttons: false,
	    autoplay: true,
	    autoplayDelay: 6000,
	    autoScaleLayers: false,
	    slideAnimationDuration: 1500
	});

	$('.sp-mask').css({'height':($(window).height() - 120 ) +'px'});
	$('.sp-slide').css({'height':($(window).height() - 120 ) +'px'});



/* ==================================================================
                		PARALLAX REFRESH COMMAND
================================================================== */
if(!Modernizr.touch){
	$(window).stellar({
		responsive: true,
	    positionProperty: 'position',
	    horizontalScrolling: false
	});

}

/* ==================================================================
                		MASONRY PORTFOLIO GRID
================================================================== */
	var $portfolioContainer	= $('.works'),
		$portfolioMasonryContainer	= $('.portfolio-masonry-section .works');

		// filter items on button click
		$portfolioContainer.isotope({
		  filter: '*',
		  itemSelector: '.work-item',
		  animationOptions: {
		      duration: 750,
		      easing: 'linear',
		      queue: false
		  },
		  masonry: {
		    // use outer width of grid-sizer for columnWidth
		    columnWidth: '.work-item'
		  }
		});

		$portfolioContainer.infinitescroll({
	    navSelector  : '#portfolio-next-page-nav',    // selector for the paged navigation
	    nextSelector : '#portfolio-next-page-nav a',  // selector for the NEXT link (to page 2)
	    itemSelector : '.work-item ',     // selector for all items you'll retrieve
	    loading: {
	        finishedMsg: 'No more pages to load.',
	        img: 'images/loader.gif'
	      }
	    },
	    // call Isotope as a callback
	    function( newElements ) {
	    	$portfolioMasonryContainer.imagesLoaded(function(){
				$portfolioMasonryContainer.isotope( 'appended', $( newElements ) );
			});
			$('.lightbox').magnificPopup({
					type: 'image',
					gallery:{
						enabled:true
					}
				});
			}
		);


		$('#portfolio-filter a').on('click',function(){
			      var selector = $(this).attr('data-filter');
			      $portfolioContainer.isotope({
			          filter: selector,
			          animationOptions: {
			              duration: 750,
			              easing: 'linear',
			              queue: false
			          }
			      });
			    return false;
			  });


		var $optionSets = $('#portfolio-filter .portfolio-filter-btn-group'),
			     $optionLinks = $optionSets.find('a');

			     $optionLinks.on('click',function(){
			        var $this = $(this);
			    // don't proceed if already selected
			    if ( $this.hasClass('selected') ) {
			        return false;
			    }
			 var $optionSet = $this.parents('#portfolio-filter .portfolio-filter-btn-group');
			 $optionSet.find('.selected').removeClass('selected');
			 $this.addClass('selected');
		});





/* ==================================================================
                		TESTIMONIAL SLIDER
================================================================== */
$('#testimonial-carousal').owlCarousel({
	items: 1,
	autoplay: true,
	loop: true
});

/* ==================================================================
                		LIGHT BOX
================================================================== */
$('.lightbox').magnificPopup({
	type: 'image',
	gallery:{
		enabled:true
	}
});

$('.featured-gallery').magnificPopup({
	type: 'image',
	gallery:{
		enabled:true
	}
});




/* ==================================================================
                			GOOGLE MAP
================================================================== */
function b() {
    var a = {
            zoom: 8,
            scrollwheel: false,
            center: new google.maps.LatLng(34.960274, -110.048797),
            styles: [{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"stylers":[{"hue":"#00aaff"},{"saturation":-100},{"gamma":2.15},{"lightness":12}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"lightness":24}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":57}]}]
        },
        b = document.getElementById("map"),
        c = new google.maps.Map(b, a);
    new google.maps.Marker({
        position: new google.maps.LatLng(34.960274, -110.048797),
        map: c,
        title: "Snazzy!"
    })
}
if($('#map').length > 0){
	//google.maps.event.addDomListener(window, "load", b);
}



});


 

/* ==================================================================
                        SIDE MENU
================================================================== */
(function(e) {

	var bodyEl = document.body,
		content = document.querySelector( 'body' ),
		openbtn = document.getElementById( 'side-menu-open-button' ),
		closebtn = document.getElementById( 'side-menu-close-button' ),
		isOpen = false;

	function init() {
		initEvents();
		
	}

	function initEvents() {
		openbtn.addEventListener( 'click', toggleMenu );
		if( closebtn ) {
			closebtn.addEventListener( 'click', toggleMenu );
		}
		e.stopPropagation();		

		// close the menu element if the target it´s not the menu element or one of its descendants..
		content.addEventListener( 'click', function(ev) {			
			var target = ev.target;
			if( isOpen && target !== openbtn ) {
				toggleMenu();				
			}
		} );
	}

	function toggleMenu() {
		if( isOpen ) {
			classie.remove( bodyEl, 'show-menu' );
		}
		else {
			classie.add( bodyEl, 'show-menu' );
		}
		isOpen = !isOpen;
		  
	}
	init();

})();

 