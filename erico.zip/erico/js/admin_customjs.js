// JavaScript Document



//Tab Module


var $=jQuery
(function($,window){
	'use-strict';

	var elements = {};

	//View

	var constructTab = function(tabContainer){
		var tabContentEl = $(tabContainer).find('.tab-content > li');
		$.each(tabContentEl,function(){
			hideTabs(this);
		});
		var activeTab = ($('.tab-legend .active').length)? $('.tab-legend .active') : $('.tab-legend > li:first-child');
		showTab(activeTab);
	};

	var hideTabs = function(tab,callback){
		$(tab).hide().removeClass('active');
		if(callback){
			callback();
		}
	};

	var showTab = function(tab){
		var index = tab.index();

		hideTabs($('.tab-content .active'));
		$('.tab-legend .active').removeClass('active').addClass('inactive');
		$('.tab-legend > li').eq(index).removeClass('inactive').addClass('active');
		$('.tab-content > li').eq(index).show().addClass('active');
	};


	//Controller
	var tabController = function(tabContainer){
		var tabLegendEl = $(tabContainer).find('.tab-legend li');
		$.each(tabLegendEl,function(){
			$(this).on('click', function(){
				var tabElement = $(this);
				showTab(tabElement);
			});
		});
	};

	var init = function(){
		console.log('Initiating Tab Module');
		var self = this;
		var tabElement = $('.tab');

		$.each(tabElement, function(){
			constructTab(this);
			tabController(this);
		});
	};

	//public
	var tabModule = {
		init: init
	};

	//transport
	if(typeof(define)==='function' && define.amd){
		define(tabModule);
	} else if (typeof(exports)==='object'){
		module.tabModule = tabModule;
	} else {
		window.tabModule = tabModule;
	}

}(jQuery,window));

jQuery(document).ready(function($){
	
			 tabModule.init();
		});
		

 
 
 		jQuery(document).ready(function() {
 
jQuery(document).on('click','.webupload_image_button',function() {
	 var id=jQuery(".addedRows > tbody > tr").length;
	var this_html = jQuery(this);
tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
 window.send_to_editor = function(html) {
 imgurl = jQuery('img',html).attr('src');
this_html.parent().parent().find('input[type="text"]').val(imgurl);
var msg='<img src="'+imgurl+'">';
this_html.parent().parent().find('div[class="imgclass"]').html(msg);




 tb_remove();
}
 return false;
});






 
 
});



		
function addMoreRows(frm) {
var rowCount =jQuery(".addedRows > tbody > tr").length+1;
var recRow = '<tr id="rowCount'+rowCount+'"><td><input id="webupload_image'+rowCount+'" class="webupload_image" type="text" size="36" name="sa_options[webtech_images][]" value="" /><input type="button" value="Upload Image" class="webupload_image_button" /> </td><td><div class="imgclass"></div></td><td> <a class="delete_row" href="javascript:void(0);" onclick="removeRow('+rowCount+');">Delete</a></td></tr>';
jQuery('.addedRows').append(recRow);
}

function removeRow(removeNum) {
	
	
jQuery('#rowCount'+removeNum).remove();


}






