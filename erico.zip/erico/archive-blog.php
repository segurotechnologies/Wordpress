<?php echo get_header(); 

global $wp_post_types;

$post_type = 'blog';

$description = $wp_post_types[$post_type]->description;

 if ( have_posts() ) :

?>

 <section class="page-title-section">

    <div class="container">

      <div class="row">

        <h1><?php <?php  _e( 'Blog','erico');?></h1>

        <h3><?php echo $description; ?></h3>

      </div>

    </div>

    <div class="breadcumb">  <a href="<?php echo home_url(); ?>"><?php <?php  _e( 'HOME','erico');?></a>/ <span>BLOG</span>  </div>

  </section>

  

    <!--========Content Section=========-->

  <section class="aboutus-details-section">

    <div class="container">

      <div class="row">

        <div class="aboutus-contents">

          <div class="row"> 

            <!--=======left section=====-->

            <div class="col-md-9">

             <div class="row blog-wrapper "> 

              <?php

              ?>

                <?php while ( have_posts() ) : the_post(); 

				global $post;

				 $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'thumbnail') );

				?>

                <!--=======blog 1==========-->

                <div class="col-md-6 blog_margin">

                  <div class="blog-post">

                    <div class="blog-img-wrapper"> <img src="<?php echo $url; ?>" alt="Blog Image"> </div>

                    <div class="blog-post-title-wrapper"> <span class="post-date"><?php echo get_the_date( 'F d,Y' ); ?></span>

                    <h3 class="post-title"> <a href="<?php echo  get_permalink()?>"><?php echo $post->post_title; ?></a> </h3>

                    <p class="post-meta">by <a href="<?php echo  get_permalink()?>" class="post-author"><?php echo get_field('author',$post->ID); ?></a> in <a href="#" class="post-category"><?php $categories = get_the_terms($post->ID, 'blog_taxonomy' );  echo $categories[0]->name; ?></a></p>

                    </div>

                    <div class="blog-post-excerpt">

                      <p><?php echo $post->post_content; ?></p>

                      <a href="<?php echo  get_permalink()?>" class="read-more">-<?php  _e( 'Read More','erico');?></a> </div>

                   </div>

                </div>

                <?php endwhile; ?>

               <?php else : ?>

               <h2><?php  _e( 'Not Found','erico'); ?></h2>

			  <?php endif; ?>

              <!--End Blog --> 

                

          </div>

         </div>

            

            <!--=======right section=====-->

            <div class="col-md-3 side_bar_blog side_bar_blog_pic"> 

              <!--===widget 1=========-->

              <div class="widget_blog">

                <h3>Recent Posts</h3>

                <ul class="recent_post">

					<?php

                    $new_loop = new WP_Query( array(

                    'post_type' => 'blog',

                    'posts_per_page' => 6,

                    'order'=>'ASC',

                    'post_status'=>'publish' ) );

                     // put number of posts that you'd like to display

                     ?>

    

                    <?php if ( $new_loop->have_posts() ) : ?>

                   <?php while ( $new_loop->have_posts() ) : $new_loop->the_post();

                   global $post; ?>

                   <li><a href="<?php echo  get_permalink()?>"><?php echo $post->post_title;  ?></a></li>

                   <?php endwhile;

                   endif;?>

               </ul>

             </div>

              <!--===widget 2======-->

              <div class="widget_blog">

                <h3>Archives</h3>

                <ul class="list_arrow">

                 <?php echo cpt_wp_get_archives('blog'); ?>

                </ul>

              </div>

              <!--======widget 3 ========-->

              <div class="widget_blog">

                <h3>Categories</h3>

                <ul class="list_arrow">

                            <?php   

              	   $taxonomy = 'blog_taxonomy';

                   $tax_terms = get_terms($taxonomy);?>

                

                  <?php

                   foreach ($tax_terms as $tax_term) 

				   {

                   echo '<li><a href="#" title="'. $tax_term->name . '" ' . '>' . $tax_term->name.'</a></li>';

				   }?>

                </ul>

              </div>

              

              <!--======widget 4 ========-->

              <div class="widget_blog">

                <h3>Tags</h3>

                <?php  $terms = get_terms('post_tag'); ?>

                <ul class="list_arrow">

                <?php 

				foreach ($terms as $term) {

                	    $url = esc_attr(get_term_link($term,'tag') );

echo '<li><a href="#" title="' .$term->name. '" ' . '>' . $term->name.'</a></li>';

				}

?>

                </ul>

              </div>

              <!--==========End Section=========--> 

            </div>

            

            <!-- ABOUT TEXT --> 

            

          </div>

        </div>

      </div>

    </div>

  </section>



<?php echo get_footer(); ?>